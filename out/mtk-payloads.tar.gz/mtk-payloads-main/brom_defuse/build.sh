#!/bin/sh
make
